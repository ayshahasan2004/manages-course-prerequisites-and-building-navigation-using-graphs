//////////Aysha Hasan
/////////1220352
///////// Sec:1
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_COURSES 100 // Maximum number of courses
#define MAX 100
#define INF 999999
#define MAX_PREREQUISITES 10 /////////// Maximum number of prerequisites for a course
#define MAX_NAME_LENGTH 100 // Maximum length of a course name

typedef struct Vertex {
    int index;
    struct Vertex* next;
} Vertex;

typedef struct {
    Vertex* head;
} Graph;

typedef struct {
    char name[MAX_NAME_LENGTH];
    int index; // Store the index of the course in the sorted order
} CourseIndex;

typedef struct QueueNode {
    int index;
    struct QueueNode* next;
} QueueNode;

typedef struct {
    QueueNode* front;
    QueueNode* rear;
} Queue;

typedef struct {
    char name[100]; //////////// Course name
    char prerequisites[MAX_PREREQUISITES][100]; // Array to store prerequisites
    int num_prerequisites; // Number of prerequisites for the course
} Course;


char buildings[MAX][100];
int matrix[MAX][MAX];
int numBuildings = 0;
int totalCost = 0;

void menu();
void readFileBuildings();
void addEdge(char source[], char destination[], int distance);
int findIndex(char v[]);
int isExist(char v[]);
void dijkstra(char source[], bool visited[], int cost[], int parent[]);
int find_minimum(bool visited[], int cost[]);
void getPath(char source[], char destination[]);
int  readFileCourses( Course courses[]);
Graph* createGraph(int num_vertices);
void addEdgeCourse(Graph* graph, int src, int dest);
Queue* createQueue();
void enqueue(Queue* queue, int index);
int dequeue(Queue* queue);
bool isEmpty(Queue* queue);
void topologicalSort(Course courses[], int num_courses);
int findCourseIndex(Course courses[], int num_courses,  char* course_name);

int main(void) {
    int choice;
    int readOnce = 0;
    char source[MAX];
    char destination[MAX];
    Course courses[MAX_COURSES]; // Array to store courses
    int num_Courses=readFileCourses(courses);

    while (1) {
        menu();
        scanf("%d", &choice);

        switch (choice) {
        case 1:
            if (readOnce == 0) {
                readFileBuildings();
                num_Courses=readFileCourses(courses);
                readOnce = 1;
            } else {
                printf("The file has already been read.\n");
            }
            break;
        case 2:
            if (readOnce == 0) {
                printf("You should read the file first.\n");
            } else {
                printf("Enter the source building:\n");
                scanf("%s", source);
                if (!isExist(source)) {
                    printf("This building does not exist.\n");
                    continue;
                }
            }
            break;
        case 3:
            if (readOnce == 0) {
                printf("You should read the file first.\n");
            } else {
                printf("Enter the destination building:\n");
                scanf("%s", destination);
                if (!isExist(destination)) {
                    printf("This building does not exist.\n");
                    continue;
                }
                printf("The shortest path from %s to %s using Dijkstra's algorithm:\n", source, destination);
                getPath(source, destination);
            }
            break;
        case 4:
            printf("The sorted done ...\n ");
            printf("I merged case 4 with case 5 \n");
            break;
        case 5:
             if (readOnce == 0) {
                printf("You should read the file first.\n");
            } else {
            topologicalSort(courses ,num_Courses );
            }
            break;
        case 6:
            exit(1);
            break;
        default:
            printf("Invalid choice. Please try again.\n");
        }
    }
    return 0;
}

void menu() {
    printf("\n");
    printf("Choose a task:\n");
    printf("1. Load the two files .\n");
    printf("2. Calculate the shortest distance between two buildings.\n");
    printf("3. Print the shortest route between two buildings and the total distance.\n");
    printf("4. Sort the courses using the topological sort.\n");
    printf("5. Print the sorted courses.\n");
    printf("6. Exit the application.\n");
    printf("-----------------------------------------------------------------------------------------------\n");

}

void readFileBuildings() {
    FILE *file;
    file = fopen("input_buildings.txt", "r");
    if (file == NULL) {
        printf("Unable to open the file.\n");
        exit(1);
    }

    char line[300]; // Array to store the line
    char source[100], destination[100]; // Arrays to store source and destination
    int distance;

    while (fgets(line, sizeof(line), file) != NULL) { // Continue until end of file
        // Use strtok to split the line by '#'
        char *token = strtok(line, "#");
        if (token != NULL) {
            strcpy(source, token);
            token = strtok(NULL, "#");
            if (token != NULL) {
                strcpy(destination, token);
                token = strtok(NULL, "#");
                if (token != NULL) {
                    distance = atoi(token);/////converte to integer

                    // Check if source and destination buildings exist, and add them if they don't
                    if (!isExist(source)) {
                        strcpy(buildings[numBuildings], source);
                        numBuildings++;
                    }
                    if (!isExist(destination)) {
                        strcpy(buildings[numBuildings], destination);
                        numBuildings++;
                    }

                    // Add the edge to the graph
                    addEdge(source, destination, distance);
                }
            }
        }
    }
    fclose(file);
}
int readFileCourses(Course courses[]) {
    FILE *file;
    file = fopen("input_courses.txt", "r");
    if (file == NULL) {
        printf("Unable to open the file.\n");
        exit(1);
    }
    char line[300];
     //////courses Array to store courses
    int num_courses = 0; // Number of courses read

    while (fgets(line, sizeof(line), file) != NULL) {
        char *token = strtok(line, "#");
        if (token != NULL) {
            strcpy(courses[num_courses].name, token); // Store the course name
            token = strtok(NULL, "#");
            if (token != NULL) {
                // Split the prerequisites by comma (if there are multiple prerequisites)
                char *prerequisite = strtok(token, "#");
                int i = 0;
                while (prerequisite != NULL && i < MAX_PREREQUISITES) {
                    strcpy(courses[num_courses].prerequisites[i], prerequisite); // Store each prerequisite
                    i++;
                    prerequisite = strtok(NULL, "#");
                }
                courses[num_courses].num_prerequisites = i; // Store the number of prerequisites
            } else {
                courses[num_courses].num_prerequisites = 0; // No prerequisites
            }
            num_courses++;
        }
    }
    fclose(file);

   /* // Print the courses and their prerequisites
    for (int i = 0; i < num_courses; i++) {
        printf("Course: %s\n", courses[i].name);
        printf("Prerequisites:");
        for (int j = 0; j < courses[i].num_prerequisites; j++) {
            printf(" %s", courses[i].prerequisites[j]);
        }
        printf("\n");
    }*/
    return num_courses;
}

void addEdge(char source[], char destination[], int distance) {
    int index_i = findIndex(source);
    int index_j = findIndex(destination);
    matrix[index_i][index_j] = distance;/////// indirected graph
    matrix[index_j][index_i] = distance;
}

int findIndex(char v[]) {/////// to find the index of the source or the destination
    for (int i = 0; i < numBuildings; i++) {
        if (strcmp(buildings[i], v) == 0)
            return i;
    }
    return -1;
}

int isExist(char v[]) {/////// to check if the source or destination is exist or not compare by using strcmp function
    for (int i = 0; i < numBuildings; i++) {
        if (strcmp(buildings[i], v) == 0)
            return 1;
    }
    return 0;
}

void dijkstra(char source[], bool visited[], int cost[], int parent[]) {/////////int parent[]: An array to store the parent of each node in the shortest path tree
    //////////////////int cost[]: An array to store the minimum cost (distance) from the source node to each node
    /////////////////bool visited[]: An array to keep track of visited nodes
    /////////////////char source[]: The source node (building) from which we start the algorithm
    int v = findIndex(source);

    for (int i = 0; i < numBuildings; i++) {/////// intilaize all elements in the building array (var visited to false and cost to infinty )
        cost[i] = INF;
        visited[i] = false;
        parent[i] = -1;
    }

    cost[v] = 0;

    for (int i = 0; i < numBuildings; i++) {
        int min = find_minimum(visited, cost);
        visited[min] = true;

        for (int j = 0; j < numBuildings; j++) {/////////////////// to calculate the shortest path
            if (!visited[j] && matrix[min][j] && cost[min] + matrix[min][j] < cost[j]) {
                cost[j] = cost[min] + matrix[min][j];
                parent[j] = min;
            }
        }
    }
}

int find_minimum(bool visited[], int cost[]) {////////to find the minimum cost
    int min = INF, min_index;

    for (int v = 0; v < numBuildings; v++){
        /////travers  the array building to calculate the minimum cost
        if (!visited[v] && cost[v] <= min) {
            min = cost[v];
            min_index = v;
        }
    }
        return min_index;
}


void getPath(char source[], char destination[]) {///// function receve the source college and destination
    bool visited[MAX]; /////boolean array initaial false
    int cost[MAX];/////// int array thats contains the cost
    int parent[MAX];

    dijkstra(source, visited, cost, parent);/////// call the dijkstra function

    int i = findIndex(destination);////////if the cost it infinty thats no paths to this college
    if (cost[i] == INF) {
        printf("No path exists between %s and %s.\n", source, destination);
        return;
    }

    char path[MAX][100];
    int path_length = 0;

    while (i != -1) {
        strcpy(path[path_length], buildings[i]);
        path_length++;
        i = parent[i];
    }

    printf("Path: ");
    for (int j = path_length - 1; j > 0; j--) {
        printf("%s --> %dKm --> ", path[j], matrix[findIndex(path[j])][findIndex(path[j - 1])]);
        totalCost += matrix[findIndex(path[j])][findIndex(path[j - 1])];
    }
    printf("%s\n", path[0]);
    printf("Total cost: %dKm\n", totalCost);
    totalCost = 0;  // Reset total cost for the next query
}
// Create a graph with num_vertices vertices
/*Graph* createGraph(int num_vertices) {
    Graph* graph = (Graph*)malloc(sizeof(Graph) * num_vertices); // Allocate memory for the graph
    for (int i = 0; i < num_vertices; i++) {
        graph[i].head = NULL; // Initialize the head pointer of each vertex to NULL
    }
    return graph;
}
*/
/*// Add an edge between source and destination vertices
void addEdgeCourse(Graph* graph, int src, int dest) {
    Vertex* new_vertex = (Vertex*)malloc(sizeof(Vertex)); // Allocate memory for the new vertex
    new_vertex->index = dest; // Set the index of the new vertex to the destination vertex index
    new_vertex->next = graph[src].head; // Set the next pointer of the new vertex to the current head of the adjacency list for the source vertex
    graph[src].head = new_vertex; // Update the head of the adjacency list for the source vertex to be the new vertex
}*/

// Create an empty queue
Queue* createQueue() {
    Queue* queue = (Queue*)malloc(sizeof(Queue)); // Allocate memory for the queue
    queue->front = NULL;
    queue->rear = NULL;
    return queue;
}

// Add an element to the rear of the queue
void enqueue(Queue* queue, int index) {
    QueueNode* new_node = (QueueNode*)malloc(sizeof(QueueNode)); // Allocate memory for the new node
    new_node->index = index;
    new_node->next = NULL;
    if (queue->rear == NULL) {
        queue->front = new_node; // If the queue is empty, set both front and rear to the new node
        queue->rear = new_node;
    } else {
        queue->rear->next = new_node; // Otherwise, add the new node to the rear of the queue
        queue->rear = new_node;
    }
}

// Remove and return the element at the front of the queue
int dequeue(Queue* queue) {
    if (queue->front == NULL) {
        return -1; // If the queue is empty, return -1
    }
    QueueNode* temp = queue->front;
    int index = temp->index;
    queue->front = queue->front->next;
    if (queue->front == NULL) {
        queue->rear = NULL; // If the queue becomes empty after dequeue, set rear to NULL
    }
    free(temp);
    return index;
}

// Check if the queue is empty
bool isEmpty(Queue* queue) {
    return queue->front == NULL;
}

// find the index of a course in the courses array by its name
int findCourseIndex(Course courses[], int num_courses, char* course_name) {
    for (int i = 0; i < num_courses; i++) {
        if (strcmp(courses[i].name, course_name) == 0) {
            return i; // return the index if the course name matches
        }
    }
    return -1; // Return -1 if the course is not found
}
int compareCourseIndex(const void* a, const void* b) {
    return strcmp(((CourseIndex*)a)->name, ((CourseIndex*)b)->name);
}

Graph* createGraph(int num_vertices) {
    Graph* graph = (Graph*)malloc(sizeof(Graph) * num_vertices);
    for (int i = 0; i < num_vertices; i++) {
        graph[i].head = NULL;
    }
    return graph;
}

void addEdgeCourse(Graph* graph, int src, int dest) {
    Vertex* new_vertex = (Vertex*)malloc(sizeof(Vertex));
    new_vertex->index = dest;
    new_vertex->next = graph[src].head;
    graph[src].head = new_vertex;
}

void topologicalSort(Course courses[], int num_courses) {
    // Create a graph
    Graph* graph = createGraph(num_courses);

    // Build the graph and add edges based on prerequisites
    for (int i = 0; i < num_courses; i++) {
        for (int j = 0; j < courses[i].num_prerequisites; j++) {
            int prereq_index = findCourseIndex(courses, num_courses, courses[i].prerequisites[j]);
            if (prereq_index != -1) {
                addEdgeCourse(graph, prereq_index, i);
            }
        }
    }

    // Calculate indegrees
    int indegree[MAX_COURSES] = {0};
    for (int i = 0; i < num_courses; i++) {
        for (Vertex* v = graph[i].head; v != NULL; v = v->next) {
            indegree[v->index]++;
        }
    }

    // Initialize a queue
    Queue* queue = createQueue();

    // Enqueue courses with indegree 0
    for (int i = 0; i < num_courses; i++) {
        if (indegree[i] == 0) {
            enqueue(queue, i);
        }
    }

    // Perform topological sorting using BFS
    int sorted_courses[MAX_COURSES];
    int sorted_index = 0;
    while (!isEmpty(queue)) {
        int current = dequeue(queue);
        sorted_courses[sorted_index++] = current;
        for (Vertex* v = graph[current].head; v != NULL; v = v->next) {
            indegree[v->index]--;
            if (indegree[v->index] == 0) {
                enqueue(queue, v->index);
            }
        }
    }

    // Create an array of CourseIndex structs to store course names and their original indices
    CourseIndex course_indices[MAX_COURSES];
    for (int i = 0; i < num_courses; i++) {
        strcpy(course_indices[i].name, courses[i].name);
        course_indices[i].index = sorted_courses[i];
    }

    // Sort the CourseIndex array alphabetically by course name
    qsort(course_indices, num_courses, sizeof(CourseIndex), compareCourseIndex);

    // Print the sorted courses
    for (int i = 0; i < num_courses; i++) {
        printf("%s\n", course_indices[i].name);
    }

    // Free allocated memory
    free(queue);
    free(graph);
}
